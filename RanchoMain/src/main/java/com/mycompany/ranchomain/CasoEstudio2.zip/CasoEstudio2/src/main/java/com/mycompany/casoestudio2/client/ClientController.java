package com.mycompany.casoestudio2.client;

import com.mycompany.casoestudio2.farm.Animal;

public class ClientController {
    
}
