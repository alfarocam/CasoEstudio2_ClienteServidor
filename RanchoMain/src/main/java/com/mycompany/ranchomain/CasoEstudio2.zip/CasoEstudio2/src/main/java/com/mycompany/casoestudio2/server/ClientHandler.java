package com.mycompany.casoestudio2.server;

import com.mycompany.casoestudio2.farm.Animal;
import java.io.*;
import java.net.Socket;
import java.util.List;

public class ClientHandler {
    
}
