package com.mycompany.casoestudio2.server;

import com.mycompany.casoestudio2.farm.Animal;

public class CowController {
}
